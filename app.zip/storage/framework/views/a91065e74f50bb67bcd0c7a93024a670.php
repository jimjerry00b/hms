<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: sans-serif; max-width: 2480px; margin: 0 auto;}
        .header { text-align: center; margin-bottom: 20px; }
        .invoice-box { padding: 20px; border: 1px solid #ccc; }
        .footer { text-align: center; font-size: 12px; margin-top: 40px; }
    </style>
</head>
<body>
<div class="invoice-box">
    <div class="header">
        <h2>Rent Invoice <br><?php echo e($rent->house->address); ?></h2>
        <p>Flat No : <?php echo e($rent->tenant->flat_id); ?></p>
        <p><?php echo e(\Carbon\Carbon::parse($rent->month)->format('F Y')); ?></p>
    </div>

    <p><strong>Name:</strong> <?php echo e($rent->tenant->name); ?></p>
    <p><strong>Phone:</strong> <?php echo e($rent->tenant->phone); ?></p>
    <p><strong>House:</strong> <?php echo e($rent->house->address); ?></p>

    <hr>

    <p><strong>House Rent:</strong> <?php echo e(number_format($rent->amount, 2)); ?> BDT</p>
    <p><strong>Water Bill:</strong> <?php echo e(number_format(800, 2)); ?> BDT</p>
    <hr>
    <p><strong>Total:</strong> <?php echo e(number_format($rent->amount + 800, 2)); ?> BDT</p>
    <p><strong>Status:</strong> <?php echo e(ucfirst($rent->status)); ?></p>
    <p><strong>Payment Date:</strong> <?php echo e($rent->payment_date ?? 'N/A'); ?></p>

    <hr>

    <p><strong>Note:</strong><br><?php echo e($rent->note); ?></p>

    <div class="footer">
        <p>Thank you for your payment!</p>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\xampp_2\htdocs\house_management_system\resources\views/backend/rent/invoice.blade.php ENDPATH**/ ?>