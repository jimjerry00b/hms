
<?php $__env->startSection('title', 'Dashboard | Flats'); ?>
<?php $__env->startSection('content'); ?>

<section class="section">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">All Flats</h5>

                    <a href="<?php echo e(route('tenants.create')); ?>"><button type="button" class="btn btn-outline-primary btn-sm">Add</button></a>

                    <!-- Table with stripped rows -->
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Name</th>
                                <th scope="col">Description</th>
                                <th scope="col">House name</th>
                                <th scope="col">Rent</th>
                                <th scope="col">Electric A/C</th>
                                <th scope="col">Electric Meter No.</th>
                                <th scope="col">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $flats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>                                
                                <td><?php echo e($flat->name); ?></td>
                                <td><?php echo e($flat->description); ?></td>                                
                                <td><?php echo e($flat->house->address); ?></td>
                                <td><?php echo e($flat->monthly_rent); ?></td>
                                <td><?php echo e($flat->electricityBills->account_number); ?></td>
                                <td><?php echo e($flat->electricityBills->meter_number); ?></td>
                                <td><?php echo e(($flat->is_active == 1)? 'Active' : 'Inactive'); ?></td>                                
                                <td>
                                    <div class="" role="group" aria-label="Basic outlined example">
                                        <a class="btn btn-outline-primary btn-sm" href="<?php echo e(route('flats.edit', $flat->id)); ?>">Edit</a>
                                       
                                        <form class="d-inline" action="<?php echo e(route('flats.destroy', $flat->id )); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-outline-danger btn-sm" type="submit" onclick="return confirm('Are you sure you want to delete <?php echo e($flat->name); ?>?')">Delete</button>
                                        </form>
                                      </div>

                                </td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <!-- End Table with stripped rows -->


                </div>
            </div>

        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp_2\htdocs\house_management_system\resources\views/backend/flat/index.blade.php ENDPATH**/ ?>