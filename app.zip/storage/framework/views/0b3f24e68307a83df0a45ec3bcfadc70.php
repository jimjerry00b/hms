<?php $__env->startSection('title', 'Users'); ?>
<?php $__env->startSection('content'); ?>

<div class="pagetitle">
    <h1>Users</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
            <li class="breadcrumb-item active">Users</li>
        </ol>
    </nav>
</div><!-- End Page Title -->

<section class="section">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">All Users</h5>

                    <a href="<?php echo e(route('user.create')); ?>"><button type="button" class="btn btn-outline-primary btn-sm">Add</button></a>

                    <!-- Table with stripped rows -->
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Name</th>
                                <th scope="col">Status</th>
                                <th scope="col">Type</th>
                                <th scope="col">Start Date</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e(($users->currentPage()-1)* $users->perPage() + $loop->iteration); ?></th>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e(($user->is_active == 1)? "Active" : "Deactived"); ?></td>
                                <td><?php echo e($user->role->name); ?></td>
                                <td><?php echo e($user->created_at); ?></td>
                                <td>
                                    <div class="" role="group" aria-label="Basic outlined example">
                                        <a class="btn btn-outline-primary btn-sm" href="<?php echo e(route('user.edit', $user->id)); ?>">Edit</a>
                                        <a class="btn btn-outline-success btn-sm" href="">Ban User</a>

                                        <?php if($user->is_deletable == 1): ?>
                                            <form class="d-inline" action="<?php echo e(route('user.destroy', $user->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="btn btn-outline-danger btn-sm" type="submit" onclick="return confirm('Are you sure you want to delete <?php echo e($user->name); ?>?')">Delete</button>
                                            </form>
                                        <?php endif; ?>
                                      </div>

                                </td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <!-- End Table with stripped rows -->


                </div>
            </div>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp_2\htdocs\house_management_system\resources\views/backend/users/index.blade.php ENDPATH**/ ?>