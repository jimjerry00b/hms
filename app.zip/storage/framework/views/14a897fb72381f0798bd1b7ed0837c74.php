
<?php $__env->startSection('title', 'Dashboard | Rents'); ?>
<?php $__env->startSection('content'); ?>

<section class="section">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">All Rents</h5>

                    <div class="float-start">
                        <a href="<?php echo e(route('rents.create')); ?>"><button type="button" class="btn btn-outline-primary btn-sm">Add</button></a>
                    </div>

                    <div class="float-start">
                        <form method="GET" action="<?php echo e(route('rents.due-report')); ?>" class="mb-3 d-flex align-items-center">
                            <label class="mx-2">Status</label>
                            <select name="status" class="form-select mx-2">
                                <option value="0">All</option>
                                <option value="paid">Paid</option>
                                <option value="unpaid">Unpaid</option>
                                <option value="partial">Partial</option>
                            </select>
                            <button class="btn btn-sm btn-primary mx-2">Filter</button>
                        </form>
                    </div>
                    
                    <div class="float-end">
                        <form method="GET" action="<?php echo e(route('rents.due-report')); ?>" class="mb-3">
                            <label>Select Month:</label>
                            <input type="month" name="month" value="" required>
                            <button class="btn btn-sm btn-primary">Filter</button>
                        </form>
                    </div>

                    <!-- Table with stripped rows -->
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Tenant</th>
                                <th scope="col">House</th>
                                <th scope="col">Month</th>
                                <th scope="col">Amount</th>
                                <th scope="col">Status</th>
                                <th scope="col">Payment Date</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $rents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>                                
                                <td><?php echo e($rent->tenant->name); ?></td>
                                <td><?php echo e($rent->house->name); ?></td>                                
                                <td><?php echo e($rent->month); ?></td>
                                <td><?php echo e($rent->amount); ?></td>
                                <td><?php echo e($rent->status); ?></td>
                                <td><?php echo e(($rent->payment_date)? $rent->payment_date : 'N/A'); ?></td>
                                <td>
                                    <div class="" role="group" aria-label="Basic outlined example">
                                        <a class="btn btn-outline-primary btn-sm" href="<?php echo e(route('rents.bill-check', $rent->id)); ?>">Bill Check</a>
                                        <a class="btn btn-outline-primary btn-sm" href="<?php echo e(route('rents.invoice', $rent->id)); ?>">PDF Download</a>
                                        <a class="btn btn-outline-primary btn-sm" href="<?php echo e(route('rents.edit', $rent->id)); ?>">Edit</a>
                                       
                                        <!-- <form class="d-inline" action="<?php echo e(route('rents.destroy', $rent->id )); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-outline-danger btn-sm" type="submit" onclick="return confirm('Are you sure you want to delete <?php echo e($rent->name); ?>?')">Delete</button>
                                        </form> -->
                                      </div>

                                </td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="8">No dues found for selected month.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <!-- End Table with stripped rows -->


                </div>
            </div>

        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp_2\htdocs\house_management_system\resources\views/backend/rent/index.blade.php ENDPATH**/ ?>