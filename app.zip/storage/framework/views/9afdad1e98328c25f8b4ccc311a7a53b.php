
<?php $__env->startSection('title', 'Dashboard | Due Rent'); ?>
<?php $__env->startSection('content'); ?>

<section class="section">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Due Rent</h5>


                    <!-- Table with stripped rows -->
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Tenant Name</th>
                                <th>House</th>
                                <th>Phone</th>
                                <th>Move-in Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $tenantsWithDue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tenant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($tenant->name); ?></td>
                                <td><?php echo e($tenant->house->name ?? 'N/A'); ?></td>
                                <td><?php echo e($tenant->phone); ?></td>
                                <td><?php echo e($tenant->move_in_date); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="4">No dues found for selected month.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <!-- End Table with stripped rows -->


                </div>
            </div>

        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp_2\htdocs\house_management_system\resources\views/backend/rent/due-report.blade.php ENDPATH**/ ?>