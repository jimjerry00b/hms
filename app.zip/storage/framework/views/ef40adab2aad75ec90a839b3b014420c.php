
<?php $__env->startSection('title', 'Dashboard | Bill Generate'); ?>
<?php $__env->startSection('content'); ?>

<div class="pagetitle">
        <h1>Bill Generate</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active">Bill Generate</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section">
        <div class="row">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Bill Generate</h5>
                        <?php if(Session::has('error')): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <?php echo e(Session::get('error')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                        <!-- No Labels Form -->
                        <form class="row g-3" action="<?php echo e(route('electric.bill.store')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="col-md-12">
                                <select name="house_id" class="form-select" id="houseSelect" data-url="<?php echo e(route('flat.list', ['id' => '__ID__'])); ?>">
                                    <option selected>Select...</option>
                                    <?php $__currentLoopData = $houses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $house): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($house->id); ?>"><?php echo e($house->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['house_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-12">
                                <select name="flat_id" class="form-select" id="flat_id" data-url="<?php echo e(route('flat.details', ['id' => '__ID__'])); ?>"></select>
                                <?php $__errorArgs = ['flat_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="col-md-12">
                                <input readonly type="text" name="electric_meter_id" id="electric_meter_id" value="" class="form-control" placeholder="electric_meter_id">
                                <?php $__errorArgs = ['electric_meter_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="col-md-12">
                                <input readonly type="text" name="account_number" id="account_number" value="" class="form-control" placeholder="account_number">
                                <?php $__errorArgs = ['account_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                            <div class="col-md-12">
                                <input type="month" name="month_year" class="form-control" placeholder="Month Year">
                                <?php $__errorArgs = ['month_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-12">
                                <input type="number" name="monthly_bill" class="form-control" placeholder="Month Bill">
                                <?php $__errorArgs = ['monthly_bill'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>               

                            
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary">Save</button>
                            </div>
                        </form><!-- End No Labels Form -->

                    </div>
                </div>
            </div>
        </div>
    </section>


    <script>
    document.addEventListener('DOMContentLoaded', function() {

        const select = document.getElementById('houseSelect');
        const flatSelect = document.getElementById('flat_id');

        select.addEventListener('change', function() {
            const houseId = this.value;
            const urlTemplate = this.dataset.url;

            if (houseId) {
                const url = urlTemplate.replace('__ID__', houseId);

                fetch(url)
                    .then(response => response.json())
                    .then(result => {
                        
                        if (result.html) {
                            document.getElementById('flat_id').innerHTML = result.html;                            
                        } else {
                            document.getElementById('flat_id').innerHTML = '<p>No data found.</p>';
                        }
                    });
            }

        });

        if(flatSelect){
            flatSelect.addEventListener('change', function() {
                const flatId = this.value;
                const urlTemplate = this.dataset.url;
               
                if (flatId) {
                    const url = urlTemplate.replace('__ID__', flatId);

                    fetch(url)
                        .then(response => response.json())
                        .then(result => {
                            
                            if (result.account_number) {
                                document.getElementById('account_number').value = result.account_number;
                                document.getElementById('electric_meter_id').value = result.electric_meter_id;
                            } else {
                                //document.getElementById('flat_id').innerHTML = '<p>No data found.</p>';
                                console.error('error');
                            }
                        });
                }

            });
        }
        
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp_2\htdocs\house_management_system\resources\views/backend/electricity/bill-create.blade.php ENDPATH**/ ?>