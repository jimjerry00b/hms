<option selected id="flatSelect">Select...</option>
<?php $__currentLoopData = $flats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($flat->id); ?>"><?php echo e($flat->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp_2\htdocs\house_management_system\resources\views/backend/flat/flatListJson.blade.php ENDPATH**/ ?>